<style>

div#adcol2 .col-md-3 div{
  height: 120px;
  padding: 10px;
  padding-top:20px;
  margin-bottom:35px;
  background-color: #3c8dbc;
  border-radius:15px;
    text-align: center;
}
div#adcol2 .col-md-3 div:hover{
background-color: #222d32;
}
div#adcol2 .col-md-3 a{
  color:white;
  width:100%;
  height:200px;
  }
  div#adcol2 .col-md-3 a i{
  font-size:60px;
  }
</style>
<div class="site-index">
    <div class="jumbotron">
        <h1>Добро пожаловать!</h1>
    </div>    
</div>